export interface leavemodel{
    eid:string;
    fromdate:string;
    todate:string;
    reason:string;
    id:number;
}