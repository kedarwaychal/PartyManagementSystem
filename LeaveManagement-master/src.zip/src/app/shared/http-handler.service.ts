import { HttpClient, HttpHeaders, HttpParams } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Subject, catchError, map, tap, throwError } from "rxjs";

@Injectable({
    providedIn: 'root'
})

export class HttphandlerService{
    currrentAuthResp : any = {};

    constructor(private http:HttpClient){}


    apiurl: string = "https://leave-management-38570-default-rtdb.asia-southeast1.firebasedatabase.app/userdata.json";
    apiurlleave : string = "https://leave-management-38570-default-rtdb.asia-southeast1.firebasedatabase.app/userleavedata.json"


    postuser(userobj : any){
        return this.http.post(this.apiurl,userobj,{
            params : new HttpParams().set('auth',this.currrentAuthResp?.idToken)
        })
    }

    signUpNewUser(credentials : any){
        let payload = {
            email : credentials.username,
            password : credentials.password,
            returnSecureToken : true
        }
        return this.http.post('https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=AIzaSyC3ECn7k4VeGXwYhUMl4gMJ60s28dv3jz8',payload)
    }
    signInCurrentUser(credentials:any){
        let payload = {
            email : credentials.username,
            password :credentials.password,
        }
        return this.http.post('https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=AIzaSyC3ECn7k4VeGXwYhUMl4gMJ60s28dv3jz8',payload).pipe(tap((data:any)=>{
            this.currrentAuthResp = data;
        }))
    }


    getUsers(){
        let myParams = new HttpParams();
        myParams = myParams.append('auth',this.currrentAuthResp?.idToken)
       return this.http.get
       (this.apiurl,{
        headers : new HttpHeaders({
            'jwt' : 'ASDF',
        }),
        params : myParams ,
       }
       ).pipe(map((rawData : any)=>{
            let arr = [];
            for(let user in rawData){
                arr.push({...rawData[user],id : user})
            }
            return arr
        }),
        catchError((errD : any)=>{
            return throwError(errD.message)
        })
        )
    }

    getstaffdetails(obj : any){
        return this.http.get(this.apiurl).pipe(map((rawData : any)=>{
            let arrr = [];
            for(let user in rawData){
                arrr.push({...rawData[user],id :user})
            }
            return arrr
        }))
    }

    postLeaveData(leaveObj : any){
        return this.http.post(this.apiurlleave,leaveObj,{
            params : new HttpParams().set('auth',this.currrentAuthResp?.idToken)
        })
    }

    getLeaveDataOfStaff(userId1:any){
        return this.http.get(this.apiurlleave).pipe(map((rawData:any)=>{
            let arr = [];
            for(let user in rawData){
                if(rawData[user].userId == userId1){
                arr.push({...rawData[user],id : user})
                }
            }
            return arr
        }))
        }

 dialongStaffrelSubj = new Subject();

 getleavedataofhod(userid:any){

    return this.http.get(this.apiurlleave).pipe(map((rawData:any)=>{
        let arr = [];
        for(let user in rawData){
            console.log(rawData[user].depart)
            if(rawData[user].depart == userid){
            arr.push({...rawData[user],id : user})
            }
        }
        return arr
    }))

 }

 patchUser(id:any,obj:any){
    return this.http.patch(`https://leave-management-38570-default-rtdb.asia-southeast1.firebasedatabase.app/userdata/${id}.json`,obj)
}


patchLeaveData(id:any,obj:any){
    return this.http.patch(`https://leave-management-38570-default-rtdb.asia-southeast1.firebasedatabase.app/userleavedata/${id}.json`,obj)
}




}