import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ApplyLeaveComponent } from './apply-leave/apply-leave.component';
import { ViewLeaveComponent } from './view-leave/view-leave.component';
import { UpdateLeaveComponent } from './update-leave/update-leave.component';
import { RegistrationComponent } from './registration/registration.component';
import { LoginComponent } from './login/login.component';
import { StaffdashboardComponent } from './staffdashboard/staffdashboard.component';
import { HoddashboardComponent } from './hoddashboard/hoddashboard.component';
import { Authguard } from './shared/auth-guard.service';
import { StaffModule } from './staff/staff.module';


const routes: Routes = [
  {path:'',component:LoginComponent},
  {path:'login',component:LoginComponent},
//  {path:'applyleave',component:ApplyLeaveComponent},
//  {path:'viewleave',component:ViewLeaveComponent},
 {path:'updateleave',component:UpdateLeaveComponent},
  {path:'registration',component:RegistrationComponent},
  {path:'staffdash',loadChildren : ()=>{return import('./staff/staff.module').then((m:any)=>{return m.StaffModule})},canActivate : [Authguard]},
  {path:'hoddashboard',loadChildren : ()=>{return import('./hod/hod.module').then((m:any)=>{return m.HodModule})},canActivate : [Authguard]}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
