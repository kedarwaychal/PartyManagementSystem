import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { HttphandlerService } from '../shared/http-handler.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent {
  registrationForm: FormGroup;
  constructor(private fb: FormBuilder,private httpserve:HttphandlerService,private router : Router) {
    this.registrationForm = this.fb.group({
      firstName: ['', [Validators.required]],
      lastName: ['', Validators.required],
      contact: ['', [Validators.required,Validators.pattern('^[0-9]{10}$'),Validators.minLength(10)]],
      email: ['', [Validators.required, Validators.email]],
      department: ['', Validators.required],
      username: ['', Validators.required],
      password: ['', [Validators.required, Validators.minLength(6)]],
      role: ['HOD', Validators.required]
    });
  }
  onSubmit() {
    if (this.registrationForm.valid) {
      // Handle form submission here, e.g., sending data to the server
      console.log('Form submitted:', this.registrationForm.value);

      let obj1 = {
        username : this.registrationForm.value.username,
        password : this.registrationForm.value.password
      }
      let obj:any;
      obj=this.registrationForm.value
      obj.assignedLeaves = 10;
      obj.totalLeaves=10;
      obj.approvedleave = 0;
      obj.rejectedleave=0;
      obj.appliedLeaveData=[];
      obj.statusLeave='Pending';
      obj.id = this.registrationForm.value.username;
      this.httpserve.signUpNewUser(obj1).subscribe((rawdata:any)=>{
        this.httpserve.postuser(obj).subscribe((data:any)=>{
          console.log('hii')
        });
      })
      this.registrationForm.reset()
      this.router.navigate(['/login'])
    } else {
      // Form is invalid, display validation errors
    }
  }

}
